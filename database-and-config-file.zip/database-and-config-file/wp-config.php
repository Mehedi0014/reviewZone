<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'reviewzone' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'lNOD}S+D[3l/[pz*7J(&c@6>h jx|~=jk=oBR;B:e)-=V!I8M67}b/}}{3WZ.*^-' );
define( 'SECURE_AUTH_KEY',  '/>Qmw5KzZ0_P{<a=StM]^PB!c-sAOik->czJf{y.oSQLGzG@Qa3d:t}~OYhQ4uh*' );
define( 'LOGGED_IN_KEY',    '_bWAIeZ:]m7nfM3mS](>KM9w$VJqIFBVO7QfLOE>df/F8Bx{OcS),_B)}qMXhHg=' );
define( 'NONCE_KEY',        'K0+fX.<PRCqs/NJ{M:]0k7&T8+r=$SixCfta]ovF</2$g,!OzlN-}?bMR8&l<0+P' );
define( 'AUTH_SALT',        '[%_J1!=,C@)W>@}$5s[t*ds$980i0be5B^_-C[&1@^/xtGU8%^{nFQXDfCNma#rt' );
define( 'SECURE_AUTH_SALT', '$P@n9!26vWfSB, s:hsp{1BpuLav%,Tn9Td`*q.MMhDO(h>wVo+i2&Q<~R0QUx+K' );
define( 'LOGGED_IN_SALT',   'xW)Og-LIa##>ewx.*Vad%{aAk$#;U.r;gvs%Kt!g57Ipb=Hz`C6#>%&lr1a1->.}' );
define( 'NONCE_SALT',       'v$SME4jN^V>O8T4c)+@B>}~Fi~0Q==f)y94oY*3Cm~ FKg94kV2P.@~|m<Q~[jc{' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'rwzp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
